% result1=zeros(1,801); % 501 is 500 number 1 zero initial value
% result2=zeros(1,801);
% result3=zeros(1,801); % 501 is 500 number 1 zero initial value



for ii=1:1:400
              
      file=[num2str(ii),'-Noncrack.mat'];
      
      load(file)
      
for jj=0:1:399 
    
result1(jj+1,ii+jj)=sigma_yy(641-jj,8); 
result2(jj+1,ii+jj)=sigma_yy(641-jj,13);
result3(jj+1,ii+jj)=sigma_yy(641-jj,19);
result4(jj+1,ii+jj)=p(641-jj,8); 
result5(jj+1,ii+jj)=p(641-jj,13);
result6(jj+1,ii+jj)=p(641-jj,19);
result7(jj+1,ii+jj)=sigma_yy(641-jj,1);


% result1(jj+1,ii+jj)=sigma_yy(841,8); 
% result2(jj+1,ii+jj)=sigma_yy(941,8); 
% result3(jj+1,ii+jj)=sigma_yy(1041,8); 
% result4(jj+1,ii+jj)=p(841,8); 
% result5(jj+1,ii+jj)=p(941,8);
% result6(jj+1,ii+jj)=p(1041,8);
end

end

result1(1,:)=result11(1,:);
result2(1,:)=result22(1,:);
result3(1,:)=result33(1,:);
result4(1,:)=result44(1,:);
result5(1,:)=result55(1,:);
result6(1,:)=result66(1,:);
result7(1,:)=result77(1,:);

 Result1=sum(result1);
 Result2=sum(result2);
 Result3=sum(result3);
 Result4=sum(result4);
 Result5=sum(result5);
 Result6=sum(result6);
 Result7=sum(result7);
%  Result8=sum(result8);