


% result1=zeros(1,800); % 501 is 500 number 1 zero initial value
% result2=zeros(1,800);
% result3=zeros(1,800); % 501 is 500 number 1 zero initial value
% result4=zeros(1,800);
% result5=zeros(1,800); % 501 is 500 number 1 zero initial value
% result6=zeros(1,800);
% result7=zeros(1,800);
% result8=zeros(1,800);

% res=zeros(1,500);
% 6m equal to 
jj=100;
for ii=101:1:500
              
      file=[num2str(ii),'-Noncrack.mat'];
      
      load(file)

      result1111(1,ii-jj)=(sigma_yy(441,8)+sigma_yy(441,9))/2;
      result2222(1,ii-jj)=(sigma_yy(441,13)+sigma_yy(441,12))/2;
      result3333(1,ii-jj)=(sigma_yy(441,19)+sigma_yy(441,18))/2;
      result4444(1,ii-jj)= ( p(441,8)+p(441,9))/2;
      result5555(1,ii-jj)= ( p(441,13)+p(441,12))/2;
      result6666(1,ii-jj)=( p(441,19)+p(441,18) )/2;
      result7777(1,ii-jj)= ( sigma_yy(441,1)+sigma_yy(441,2))/2;     
%       result111(1,ii-jj)=sigma_yy(441,8);
%       result222(1,ii-jj)=sigma_yy(441,13);
%       result333(1,ii-jj)=sigma_yy(441,19);
%       result444(1,ii-jj)=p(441,8);
%       result555(1,ii-jj)=p(441,13);
%       result666(1,ii-jj)=p(441,19);
%       result777(1,ii-jj)=sigma_yy(441,1);
end
