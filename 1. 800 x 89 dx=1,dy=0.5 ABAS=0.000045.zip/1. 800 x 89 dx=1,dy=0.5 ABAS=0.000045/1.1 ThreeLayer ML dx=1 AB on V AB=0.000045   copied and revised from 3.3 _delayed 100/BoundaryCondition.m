function [UpperV12,LowerV12,UpperV22,LowerV22,UpperP,LowerP,Shear]=BoundaryCondition(surface,bounded)

% LowerV22=0 happens in all the cases which can be eliminated

switch(bounded) 
    case 1 % fully bounded              %HAVE TESTED !
    Shear=0;
    case 0 % fully bounded              %HAVE TESTED !
    Shear=1;
end 


switch(surface) 
    
    case 1 % permeable interface poroelastic/poroelastic + full bounded              %HAVE NOT TESTED YET!!!!!!!!!!!!!
        UpperV12=1;
        LowerV12=0;
        UpperV22=1;
        LowerV22=0;
        UpperP=0;
        LowerP=0;
    case 2 % Impermeable interface elastic/elastic + full bounded  DONE 
        UpperV12=1;
        LowerV12=0;
        UpperV22=0;
        LowerV22=0;
        UpperP=0;
        LowerP=0;
    case 3 % Impermeable interface elastic/poroelastic + full bounded   DONE
        UpperV12=0;
        LowerV12=-1;
        UpperV22=0;
        LowerV22=0;
        UpperP=1;
        LowerP=0;
    case 4 % Impermeable interface poroelastic/elastic + full bounded   DONE
        UpperV12=1;
        LowerV12=0;
        UpperV22=0;
        LowerV22=0;
        UpperP=0;
        LowerP=1;
    case 5 % Impermeable interface poroelastic/poroelastic + full bounded           %HAVE NOT TESTED YET!!!!!!!!!!!!!
        
        UpperV12=1;
        LowerV12=0;
        UpperV22=0;
        LowerV22=0;
        UpperP=0;
        LowerP=0;
        
        
end