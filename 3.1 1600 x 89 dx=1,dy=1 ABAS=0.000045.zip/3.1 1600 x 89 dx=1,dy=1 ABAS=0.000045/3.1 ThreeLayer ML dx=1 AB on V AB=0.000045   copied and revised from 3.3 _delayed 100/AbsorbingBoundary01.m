function [v11,v12,v21,v22]=AbsorbingBoundary01(boundary,BABS,nx,ny,v11,v12,v21,v22)
%----------------------------------------------------------------------------------------------------------------------------------------------------------------
 for   i=1:1:boundary
%     
    j=1:1:ny;
   
 
 v11(i,j)=v11(i,j)-(boundary-i)*BABS*v11(i,j);   
 v12(i,j)=v12(i,j)-(boundary-i)*BABS*v12(i,j);   
 v21(i,j)=v21(i,j)-(boundary-i)*BABS*v21(i,j);   
 v22(i,j)=v22(i,j)-(boundary-i)*BABS*v22(i,j); 
% 

%    
 end

 
%Right Side


for   i=(nx-boundary+1):1:nx
    
      j=1:1:ny;
  

 v11(i,j)=v11(i,j)-(i-(nx-boundary+1))*BABS*v11(i,j);   
 v12(i,j)=v12(i,j)-(i-(nx-boundary+1))*BABS*v12(i,j);   
 v21(i,j)=v21(i,j)-(i-(nx-boundary+1))*BABS*v21(i,j);   
 v22(i,j)=v22(i,j)-(i-(nx-boundary+1))*BABS*v22(i,j); 

end    


%Bottom Side
% 
% 
% for   j=(ny+1-boundary+1):1:ny+1
%     
%       i=1:1:nx+1;
%   
%    
%  v11(i,j)=v11(i,j)-(j-(ny-boundary+1))*BABS*v11(i,j);   
%  v12(i,j)=v12(i,j)-(j-(ny-boundary+1))*BABS*v12(i,j);   
%  v21(i,j)=v21(i,j)-(j-(ny-boundary+1))*BABS*v21(i,j);   
%  v22(i,j)=v22(i,j)-(j-(ny-boundary+1))*BABS*v22(i,j); 
% 
% 
% end  

