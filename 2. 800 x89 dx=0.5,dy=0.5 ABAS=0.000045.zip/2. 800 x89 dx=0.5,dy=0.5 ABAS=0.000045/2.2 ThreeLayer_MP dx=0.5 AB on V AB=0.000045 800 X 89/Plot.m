i=2;

switch(i)
    
    case 1
 x=-200:1:199;
plot(x,Result33(1,1:400),'r','LineWidth',1.5);
hold on
plot(x,result33,'k','LineWidth',1.5);
xlabel('Time (s)') 
ylabel('Vertical stress (psi)') 
legend({'Moving Point','Moving Load'})


    case 2
 x=-200:1:199;
plot(x,Result44(1,1:400),'r','LineWidth',1.5);
hold on
plot(x,result44,'k','LineWidth',1.5);
xlabel('Time (s)') 
ylabel('Pore pressure (psi)') 
legend({'Moving Point','Moving Load'})

    case 3
 x=-200:1:199;
 A=Result33(1,1:400)-result33(1,1:400);
plot(x,Result33(1,1:400),'r','LineWidth',1.5);
hold on
plot(x,result33,'k','LineWidth',1.5);
xlabel('Time (s)') 
ylabel('Vertical stress (psi)') 
legend({'Moving Point','Moving Load'})


end

ax = gca;
ax.FontSize = 15;

