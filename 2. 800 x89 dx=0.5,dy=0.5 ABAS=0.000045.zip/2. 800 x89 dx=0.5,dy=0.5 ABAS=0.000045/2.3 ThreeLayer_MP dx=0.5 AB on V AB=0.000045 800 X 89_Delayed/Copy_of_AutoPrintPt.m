% result1=zeros(1,801); % 501 is 500 number 1 zero initial value
% result2=zeros(1,801);
% result3=zeros(1,801); % 501 is 500 number 1 zero initial value



for ii=101:1:500
              
      file=[num2str(ii),'-Noncrack.mat'];
      
      load(file)
      
for jj=0:1:399 
    
result11(jj+1,ii+jj-100)=sigma_yy(1241-2*jj,8); 
result22(jj+1,ii+jj-100)=sigma_yy(1241-2*jj,13);
result33(jj+1,ii+jj-100)=sigma_yy(1241-2*jj,19);
result44(jj+1,ii+jj-100)=p(1241-2*jj,8); 
result55(jj+1,ii+jj-100)=p(1241-2*jj,13);
result66(jj+1,ii+jj-100)=p(1241-2*jj,19);
result77(jj+1,ii+jj-100)=sigma_yy(1241-2*jj,1);



% result1(jj+1,ii+jj)=sigma_yy(841,8); 
% result2(jj+1,ii+jj)=sigma_yy(941,8); 
% result3(jj+1,ii+jj)=sigma_yy(1041,8); 
% result4(jj+1,ii+jj)=p(841,8); 
% result5(jj+1,ii+jj)=p(941,8);
% result6(jj+1,ii+jj)=p(1041,8);
end

end

%  Result11=sum(result1);
%  Result22=sum(result2);
%  Result33=sum(result3);
%  Result44=sum(result4);
%  Result55=sum(result5);
%  Result66=sum(result6);
%  Result77=sum(result7);
%  Result8=sum(result8);