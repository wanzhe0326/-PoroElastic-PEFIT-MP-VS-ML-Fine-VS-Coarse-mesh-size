i=2;

switch(i)
    
    case 1
 x=-199:1:200;
plot(x,Result11(1,1:400),'r','LineWidth',1.5);
hold on
plot(x,result111,'k','LineWidth',1.5);
xlabel('Distance (in)') 
ylabel('Vertical stress (psi)') 
legend({'Moving Point','Moving Load'})


    case 2
x=-199:1:200;
plot(x,Result444(1,1:400),'r','LineWidth',1.5);
hold on
plot(x,result4444,'k','LineWidth',1.5);
xlabel('Distance (in)') 
ylabel('Pore pressure (psi)') 
legend({'Moving Point','Moving Load'})


    case 3
 x=-199:1:200;
A = abs(result333(1,1:400)- Result33(1,1:400));
plot(x,A,'r','LineWidth',1.5);
xlabel('Distance (in)') 
ylabel('Difference vertical stress (psi)') 
 legend({'abs(ML - MP)'})


    case 4
 x=-199:1:200;
B=abs(result666-Result66(1,1:400));
plot(x,B,'k','LineWidth',1.5);
xlabel('Distance (in)') 
ylabel('Difference pore pressure (psi)') 
 legend({'abs(ML - MP)'})

end


ax = gca;
ax.FontSize = 15;

