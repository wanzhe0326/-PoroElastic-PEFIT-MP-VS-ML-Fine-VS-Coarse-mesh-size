


% result11=zeros(1,800); % 501 is 500 number 1 zero initial value
% result22=zeros(1,800);
% result33=zeros(1,800); % 501 is 500 number 1 zero initial value
% result44=zeros(1,800);
% result55=zeros(1,800); % 501 is 500 number 1 zero initial value
% result66=zeros(1,800);


% res=zeros(1,500);
% 6m equal to 
jj=100;
for ii=101:1:500
              
      file=[num2str(ii),'-Noncrack.mat'];
      
      load(file)

      result1111(1,ii-jj)=(sigma_yy(841,8)+sigma_yy(842,8)+sigma_yy(841,9)+sigma_yy(842,9))/4;
      result2222(1,ii-jj)=( sigma_yy(841,13)+sigma_yy(842,13)+sigma_yy(841,12)+sigma_yy(842,12) )/4;
      result3333(1,ii-jj)=( sigma_yy(841,19)+sigma_yy(842,19)+sigma_yy(841,18)+sigma_yy(842,18) )/4;
      result4444(1,ii-jj)=(p(841,8)+p(842,8)+p(841,9)+p(842,9))/4;
      result5555(1,ii-jj)=( p(841,13)+p(842,13)+p(841,12)+p(842,12) )/4;
      result6666(1,ii-jj)=( p(841,19)+p(842,19)+p(841,18)+p(842,18) )/4;
      result7777(1,ii-jj)=(sigma_yy(841,1)+sigma_yy(842,1)+sigma_yy(841,2)+sigma_yy(842,2))/4;
%       
%       result111(1,ii-jj)=sigma_yy(841,8);
%       result222(1,ii-jj)=sigma_yy(841,13);
%       result333(1,ii-jj)=sigma_yy(841,19);
%       result444(1,ii-jj)=p(841,8);
%       result555(1,ii-jj)=p(841,13);
%       result666(1,ii-jj)=p(841,19);
%       result777(1,ii-jj)=sigma_yy(841,1);
      
      
end
